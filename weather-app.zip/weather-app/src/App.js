import logo from './logo.svg';
import './App.css';
import WeatherApp from './WeatherApp';

function App() {
  return (
   <WeatherApp></WeatherApp>

  );
}

export default App;
